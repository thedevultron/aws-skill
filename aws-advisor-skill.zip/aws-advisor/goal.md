# Goal and success criteria

> Use this file to keep the current outcome and things to remember visible. Copy to `.aws-advisor/memory/goal.md` only if the user authorizes persistent notes. For automation, this is the canonical objective referenced by `automate.md` and `loop.md`.

## Goal
- Status: not configured
- Desired outcome: Not provided
- Why this matters: Not provided
- Owner/decision-maker role (optional): Not provided

## Success criteria
- Measurable result: Not provided
- How it will be verified: Not provided
- Target date / review date: Not provided

## Scope
- In scope: Not provided
- Out of scope: Not provided
- AWS workload/services (high-level): Not provided
- Environment: Not provided

## Priorities and constraints
- Primary optimization objective: Balanced / not provided
- Budget range/currency/period (optional): Not provided
- Region/data-residency category: Not provided
- Security/compliance category: Not provided
- Availability/recovery/latency requirements: Not provided
- Other things to keep in mind: Not provided

## Automation (if applicable)
- Trigger / schedule / timezone: Not provided
- Inputs and outputs: Not provided
- Runtime / integrations available: Not provided
- Agent access boundary: Plan-only until explicitly configured
- Approval gates: Confirm material, production, destructive, and financial actions
- Maximum iterations / runtime / items / cost: Not provided
- Stop condition / kill switch: Not provided
- Failure, retry, and rollback behavior: Not provided

## Confirmed facts
- None recorded

## Assumptions
- None recorded

## Next actions
- [ ] Not set

## Progress notes
- YYYY-MM-DD — Not started.
