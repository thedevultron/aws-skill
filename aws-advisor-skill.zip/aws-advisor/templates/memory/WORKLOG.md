# AWS Advisor worklog

> One concise entry per substantive AWS task or meaningful follow-up. Summarize the intent, key requirements, advice, and any action; do not save a raw conversation transcript or secrets.

## Entries

_No AWS work recorded yet._

<!-- Template:
### YYYY-MM-DD — Short task title
- Goal / objective:
- New requirements or context (non-sensitive):
- Advice / files or code produced:
- Outcome / next step:
-->
