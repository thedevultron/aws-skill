# Automation run log

> Record only concise, sanitized run outcomes for an automation the user authorized. Do not log raw inputs, customer data, credentials, exact IPs, account IDs, ARNs, or secrets. Use one entry per bounded run, not one entry per internal loop step.

## Runs

_No runs recorded._

<!-- Template:
### YYYY-MM-DD HH:MM TZ — Goal/automation label
- Trigger and approved scope:
- Action category (not secret details):
- Result / postcondition:
- Retry/failure/alert summary:
- Cost/usage signal (if verified):
- Next step / stop status:
-->
