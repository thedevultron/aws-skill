# AWS decisions

> Append dated decisions with the reason and trade-off. Mark superseded decisions instead of silently deleting relevant history.

## Decisions

_No decisions recorded yet._

<!-- Template:
### YYYY-MM-DD — Short decision title
- Decision:
- Why / requirements served:
- Trade-offs and rejected alternative(s):
- Validation or revisit trigger:
- Sources: [official link](https://...)
-->
