# AWS source notes

> Keep links, dates checked, and a short note about what each source confirms. Recheck before relying on time-sensitive facts.

## Official sources checked

_None recorded yet._

<!-- Template:
- YYYY-MM-DD — [AWS source title](https://...) — relevant fact/feature and verification status.
-->
