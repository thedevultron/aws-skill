# AWS project context

> Describe the workload at a high level. Use rough ranges and generic labels; no account IDs, exact IPs, ARNs, credentials, customer data, or secret configuration.

## Goal
- Unknown

## Current state / high-level architecture
- Unknown

## Requirements and hard constraints
- Primary objective: balanced / unknown
- Availability and recovery expectations: unknown
- Latency / throughput expectations: unknown
- Region or data-residency category: unknown
- Budget range: unknown
- Security/compliance constraints: unknown

## Confirmed facts
- None recorded

## Assumptions
- None recorded

## Last updated
- YYYY-MM-DD
