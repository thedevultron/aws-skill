# Automation profile

> Store only authorized, non-sensitive automation settings. Never put credentials, access keys, account IDs, ARNs, exact IP addresses, customer payloads, or secret configuration here.

## Setup state
- Status: not configured
- Last reviewed: not reviewed

## Automation intent
- Goal: See `goal.md`
- Trigger/schedule/timezone: Not provided
- Runtime/scheduler: Not provided
- Inputs/outputs (high-level): Not provided

## Access and approvals
- Available host tools/connectors: Not checked
- Agent may: Plan-only until explicitly authorized
- Read/write/delete/deploy scope: Not provided
- Approval required for: Material, production, destructive, and financial actions (always confirm)
- Secure credential/role configuration: User-managed outside this file

## Operational limits
- Max iterations/actions/runtime/items/concurrency/cost: Not provided
- Retry/backoff policy: Not provided
- Failure/rollback/escalation behavior: Not provided
- Stop condition / kill switch: Not provided
- Logging/retention: Sanitized summary only; not provided

## Privacy and constraints
- Data residency/compliance categories: Not provided
- Other constraints: Not provided

## Last confirmed changes
- None recorded
