# Open AWS questions

> Keep only unresolved items that could change the recommendation. Ask one question at a time; accept “unknown” and document a safe assumption where possible.

## Questions

_None recorded yet._

<!-- Template:
- [ ] Question — why it matters; owner if known; next action.
-->
